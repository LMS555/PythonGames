x=10
for j in range (x):
    for i in range(x):
        if i<=j:
            print (i,end="")
    print()