plays=0
with open("plays.txt","r")as file:
    plays=int(file.read())
def add_plays(plays):
    with open("plays.txt","w")as f:
        plays+=1
        f.write(str(plays))
raining=False
#t=time
#di=distance
#f=food
#w=water
#e=energy
#w=walk
#r=run
#sg=stage
x=True
print("Hello and welcome to climb the Ziggarat!")
print("It is the year 2022 bce and you will have to climb 568 stairs.")
print("If you don't then you will have to work for the rest of your life as a poorly treaten pesent.")
print("Also if you wanted to know the only reason you are doing this is purly for peoples entertainment.")
print("And you only have 330 minutes (5 1/2 hours) so start stepping!")
t=0
f=5
d=2
di=0
e=125
while x==True:
    print("Controles.w=walk, r=run, e=energys and q=quit")
    p=input("Choose your move:")
    if p=="w":
        print("You picked to walk.")
        from random import randint
        mn=randint(25,30)
        di=di+mn
        e=e-mn
        t=t+1
        print("Distance traveled.",di)
        print("Your energy",e)
        print("Time used.",t)
    elif p=="r":
        print("You picked to run.")
        from random import randint
        mn=randint(60,92)
        di=di+mn
        e=e-mn
        t=t+5
        print("Distance traveled.",di)
        print("Your energy",e)
        print("Time used",t)
    elif p=="e":
        print("You picked to rest.")
        print("Would you like to site and reast or go to sleep.")
        print("s=sitting and gts=going to sleep.")
        p=input(":")
        if p=="s":
            from random import randint
            energize=randint(35,55)
            e=e+energize
            t=t+energize
            print(t)
        elif p=="gts":
            from random import randint
            energize=randint(60,90)
            e=e+energize
            t=t+energize
            print(t)
    elif p=="q":
        x=False
    if t>=330:
        add_plays(plays)
        x=False
        print("You are out of time. Into miserable pesent life you go! ")
    if di>=568:
        add_plays(plays)
        x=False
        print("You won! Like i said before you only gained a better physece. Now go back to your life.")
        print("Oh. And by the way.")
        print("YOU SHOULD TREAT YOURSELF NOW!;)")
    if (e<=0):
        add_plays(plays)
        print("You have colapsed due to how tired and poorly energized you are.")
        print("You better treat yourself to some rest NOW!")
        x=False
    from random import randint
    water=randint(1,10)==10
    if water:
        e=e+50
        print("Great. You have found water and are energized know!")
        print("your energy",e)
    from random import randint
    food=randint(1,10)==10
    if food:
        e=e+25
        print("Great. You have found food and are energized know!")
        print("Your energy",e)
    # if (plays%4==0and randint(1,3)==3) or raining:
    #     print("e")
    #     print("Oh no! Rain! Chose to either press ahead in a slow manner or charge ahead.")
    #     print("Also if you wish you could wait out the storm with a little rest. Chose wisely?")
    #     print("e=resting and waiting out the storm.")
    #     print("sw=slow walk")
    #     print("fw=fast walking/pressing on a a considerably dangerous pace.")
    #     input()
    #     if p=="e":
    #         di=di-15
    #         e=e+35
    #         t=t+30
    #         print(di)
    #         print(e)
    #         print(t)
    #     if randint(1,2)==2:
    #         raining=True
    #     else:
    #         raining=False
