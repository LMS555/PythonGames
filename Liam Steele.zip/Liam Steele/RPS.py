"""
F=input("Fanrenhite temp")
F=int(F)
C=(F-32)*5/9
print (C)
H=input("Height")
Lobb=input("Length of base")
Lotb=input("Length of to base")
H=int(H)
Lobb=int(Lobb)
Lotb=int(Lotb)
A=1/2*(Lobb+Lotb)*H
A=print(A)
print ("Hello and welcome to quizermania!")
print ("You will answer 3 questions about basketball.")
print ("Ready? GO!")
print ("Who has the highest score in one NBA game?")
A=input ("")
if A=="Wilt Chamberlain":
    print("Great. Next question.")
else: print("wrong.")
print ("Who has the tenth highest score in on NBA game?")
AA=input ("")
if AA=="Wilt Chamberlain":
    print("Great. Last question!")
else: print ("Wrong.")
print("Last question.")
print("Who is my favorite NBA player of all time?")
AAA=input ("")
if AAA=="Devin Booker":
    print("Great! That is it. Thank you for playing.")
else: print("wrong")
print("Thank you for playing.")
print(S)

print("Hello and welcome to the number-mainia!")
print("You will have five chances to guess a number from 1-25 on the first level")
print("The levels will get harder as the game progesses.")
print("Good luck!")
x=True
while x==True:
    from random import randint
    my_number=randint(1,25)
    G1=input("")
    if "my number"==G1:
        print("Correct")
    if "my number"!=G1:
        print("Wrong. Try again.")
    x=False
    """
print("Welcome to rock, paper, scissors Camp Fitch edition")
print("1 is rock painting(rock), 2 in arts and crafts(scissors) and 3 is pinata making(paper).")
from random import randint
rp=1
pm=2
ac=3
x=0
while x<4:
    print("Rock painting, pinata making, arts and crafts?")
    g=input("Chose your rope:")
    print(x)
    cg=randint(1,3)
    print(cg)
    g=int(g)
    if g==cg:
        print("There was a tie. Try again.")
    elif g==rp:
        if cg==ac:
            print("You win!")
            x=x+1
        else:
            print("You lose! Sorry")
            x=x-1
    elif g==ac:
        if cg==pm:
            print("You win!")
            x=x+1
        else:
            print ("You lose! Sorry.")
            x=x-1
    elif g==pm:
        if cg==rp:
            print("You win!")
            x=x+1
        else:
            print("Your lose! Sorry.")
            x=x-1

