import pygame
pygame.init()
size = (700, 500)
screen = pygame.display.set_mode(size)
pygame.display.set_caption("My Game")
clock = pygame.time.Clock()
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
background_position = [250, 0]
player_image = pygame.image.load("Tire.jpg").convert()
explosion_image=pygame.image.load("boom.png").convert()
player_image.set_colorkey(BLACK)
done = False
xpos=0
buswidth=400
def move_bus(x):
    pygame.draw.rect(screen, RED, [x, 350, buswidth, 100], 0)
    pygame.draw.ellipse(screen, BLACK, [x+25, 450, 50, 50], 0)
    pygame.draw.ellipse(screen, BLACK, [x+315, 450, 50, 50], 0)
    pygame.draw.rect(screen, BLACK, [x+350, 400, 35, 50], 0)
    for i in range(5):
        window=x+25+i*65
        pygame.draw.rect(screen,WHITE , [window, 375, 40, 40], 0)
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            print("User pressed a key.")
        elif event.type == pygame.KEYUP:
            print("User let go of a key.")
    xpos+=1
    screen.fill(WHITE)
    screen.blit(player_image, background_position)
    if xpos+buswidth<700:
        move_bus(xpos)
    else:
        screen.blit(explosion_image,[500,200])
    font = pygame.font.SysFont('Calibri', 25, True, False)
    text = font.render("los Tires   sMElil guD", True, BLACK)
    screen.blit(text, [250, 250])
    pygame.display.flip()
    clock.tick(60)
pygame.quit()
def test(s):
    print(s)
test("testing")
